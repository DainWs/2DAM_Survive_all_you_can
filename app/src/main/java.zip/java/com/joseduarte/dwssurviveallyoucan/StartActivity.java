package com.joseduarte.dwssurviveallyoucan;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.joseduarte.dwssurviveallyoucan.util.GlobalInformation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class StartActivity  extends AppCompatActivity {

    private static final int REQUEST_MAC_PERMISSIONS = 9101;

    private int userCoins = 0;
    private boolean readMacAddressPermission = false;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
        );

        GlobalInformation.context = this;
        setContentView(R.layout.activity_start);

        readMacAddressPermission =
                (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_WIFI_STATE) ==
                PackageManager.PERMISSION_GRANTED);

        if (!readMacAddressPermission) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[] { Manifest.permission.ACCESS_WIFI_STATE },
                    REQUEST_MAC_PERMISSIONS
            );
        }

        connectAndLoad();

        SharedPreferences prefs = getSharedPreferences(MyPreferencesActivity.PREFERENCES_NAME, MODE_PRIVATE);

        GlobalInformation.SELECTED_FPS_INDEX = prefs.getInt(MyPreferencesActivity.FPS_ID, 2);
        GlobalInformation.SELECTED_TIME_INDEX = prefs.getInt(MyPreferencesActivity.TIMER_ID, 2);
        GlobalInformation.USERNAME = prefs.getString(MyPreferencesActivity.USERNAME, "User");

        userCoins = prefs.getInt(MyPreferencesActivity.COINS, 0);
        ((TextView)findViewById(R.id.coins_field))
                .setText(""+userCoins);

        //GlobalInformation.BEST_RECORDS = prefs.getStringSet(
        //        MyPreferencesActivity.BEST_RECORDS,
        //        new HashSet<String>()
        //);

        MediaPlayer.create(StartActivity.this, R.raw.sounds_menu_ambient).start();

        findViewById(R.id.settings_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(StartActivity.this, MyPreferencesActivity.class);
                MediaPlayer.create(StartActivity.this, R.raw.button_presed).start();
                startActivity(intent);
            }
        });

        findViewById(R.id.start_game_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(StartActivity.this, GameActivity.class);
                MediaPlayer.create(StartActivity.this, R.raw.button_presed).start();
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        if(GlobalInformation.lastGameCoins > 0) {
            SharedPreferences prefs = getSharedPreferences(MyPreferencesActivity.PREFERENCES_NAME, MODE_PRIVATE);
            userCoins = prefs.getInt(MyPreferencesActivity.COINS, 0);
            userCoins += GlobalInformation.lastGameCoins;
            GlobalInformation.lastGameCoins = 0;

            SharedPreferences.Editor prefsEditor = prefs.edit();
            prefsEditor.putInt(MyPreferencesActivity.COINS, userCoins);
            prefsEditor.commit();

            ((TextView)findViewById(R.id.coins_field))
                    .setText(""+userCoins);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case REQUEST_MAC_PERMISSIONS:
                if(resultCode == RESULT_OK) {
                    readMacAddressPermission = true;
                    connectAndLoad();
                }
                break;
        }
    }


    public void connectAndLoad() {
        String address = "NONE";
        if ( readMacAddressPermission ) {
            WifiManager manager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            WifiInfo info = manager.getConnectionInfo();
            address = info.getMacAddress();
        }


        System.out.println("###########################################################");
        System.out.println("ADDRESS : " + address);


    }
}

