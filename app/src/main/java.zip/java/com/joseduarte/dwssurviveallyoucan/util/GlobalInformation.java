package com.joseduarte.dwssurviveallyoucan.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;

import com.joseduarte.dwssurviveallyoucan.GameActivity;
import com.joseduarte.dwssurviveallyoucan.entities.EntitiesManager;
import com.joseduarte.dwssurviveallyoucan.entities.EntitySpawner;
import com.joseduarte.dwssurviveallyoucan.entities.Player;
import com.joseduarte.dwssurviveallyoucan.graphics.Screen;

import java.util.concurrent.TimeUnit;

public class GlobalInformation {

    public static final int[] TIME_ARRAY = new int[] { 10, 30, 60, 120 };

    /**
     Las siglas QA se refieren a Quick Access
     */
    public static int FPS = 30;
    public static int QA_HORIZONTAL_SPEED = 0;

    public static int SELECTED_FPS_INDEX = 2;
    public static String USERNAME = "User";

    public static Context context = null;
    public static GameActivity gameActivity = null;

    public static int SELECTED_TIME_INDEX = 2;
    public static int selectedTime = 120;

    public static int lastGameCoins = 0;

}
