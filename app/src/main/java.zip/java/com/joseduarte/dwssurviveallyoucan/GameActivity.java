package com.joseduarte.dwssurviveallyoucan;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.joseduarte.dwssurviveallyoucan.entities.EntitiesManager;
import com.joseduarte.dwssurviveallyoucan.entities.EntityFactory;
import com.joseduarte.dwssurviveallyoucan.entities.EntitySpawner;
import com.joseduarte.dwssurviveallyoucan.entities.Player;
import com.joseduarte.dwssurviveallyoucan.game.Game;
import com.joseduarte.dwssurviveallyoucan.graphics.Screen;
import com.joseduarte.dwssurviveallyoucan.util.CollisionHandler;
import com.joseduarte.dwssurviveallyoucan.util.GlobalInformation;

import java.util.concurrent.TimeUnit;

public class GameActivity extends AppCompatActivity implements SensorEventListener {

    private Game game;
    private SensorManager mSensorManager;
    private Sensor mSensor;
    private boolean charging = false;

    private View countDownView;
    private View coinsCountView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
        );

        initGlobalConfig();

        setContentView(R.layout.activity_game);

        ViewGroup frame = (ViewGroup) findViewById(R.id.screen_frame_layout);
        frame.removeAllViews();
        frame.addView(game.getScreen());

        countDownView = getLayoutInflater()
                .inflate(R.layout.game_countdown, null, false);
        frame.addView(countDownView);

        coinsCountView = getLayoutInflater()
                .inflate(R.layout.game_coins_counter, null, false);
        frame.addView(coinsCountView);

        setCountdown (game.getCurrentTime());
        setCoinsCount(game.getCoins());

        findViewById(R.id.left_side).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EntitiesManager.playerAttackToSide(Screen.LEFT_SIDE);
                MediaPlayer.create(GameActivity.this, R.raw.sound_punch).start();
            }
        });

        findViewById(R.id.right_side).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EntitiesManager.playerAttackToSide(Screen.RIGHT_SIDE);
                MediaPlayer.create(GameActivity.this, R.raw.sound_punch).start();
            }
        });

        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null) {
            mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        } else {
            Toast t = Toast.makeText(this, R.string.no_sensor_detected, Toast.LENGTH_LONG);
            t.show();
        }
    }

    private void initGlobalConfig() {
        GlobalInformation.context = this;
        GlobalInformation.gameActivity = this;

        GlobalInformation.lastGameCoins = 0;
        GlobalInformation.selectedTime =
                GlobalInformation.TIME_ARRAY[GlobalInformation.SELECTED_TIME_INDEX];

        game = new Game(this);
        game.start();
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int precision) {}

    @Override
    public void onSensorChanged(SensorEvent evento) {
        synchronized (this) {
            switch(evento.sensor.getType()) {
                case Sensor.TYPE_ACCELEROMETER:
                    GlobalInformation.QA_HORIZONTAL_SPEED = (int) evento.values[1];
                    break;
            }
        }
    }

    protected void onResume() {
        super.onResume();
        System.out.println("############# on Resume GameActivity");

        game.resume();
        mSensorManager.registerListener(this, mSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    protected void onPause() {
        super.onPause();
        System.out.println("############# on Pause GameActivity");

        game.pause();
        mSensorManager.unregisterListener(this);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        game.restart();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        game.stop();
    }

    @Override
    public void onBackPressed() {
        if (!charging) {
            ((ViewGroup) findViewById(R.id.screen_frame_layout)).removeAllViews();
            chargeStopGame();
        }
    }

    private ProgressBar progressBar;

    public void chargeStopGame(){
        setContentView(R.layout.screen_charging);
        progressBar = findViewById(R.id.progressBar);

        new Thread(new Runnable() {
            @Override
            public void run() {
                charging = true;
                progressBar.setMax(7);
                progressBar.setProgress(0);

                game.stop(progressBar);

                game.clear();
                progressBar.setProgress(7);

                GameActivity.this.finish();
            }
        }).start();
    }

    public void endView() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(game.isGameOver()) {
                    final View newV = GlobalInformation.gameActivity
                            .getLayoutInflater()
                            .inflate(R.layout.end_title, null, false);

                    ((TextView) newV.findViewById(R.id.points_field))
                            .setText(getString(R.string.points) + " " + game.getCoins());

                    ((TextView) newV.findViewById(R.id.time_field))
                            .setText(game.getCurrentTime());

                    ViewGroup frame = (ViewGroup) findViewById(R.id.screen_frame_layout);
                    frame.removeView(countDownView);
                    frame.removeView(coinsCountView);
                    frame.addView(newV);

                    GlobalInformation.lastGameCoins = game.getCoins();

                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                TimeUnit.SECONDS.sleep(1);
                            }
                            catch (InterruptedException e) {}

                            findViewById(R.id.left_side).setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    onBackPressed();
                                }
                            });

                            findViewById(R.id.right_side).setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    ((ViewGroup) findViewById(R.id.screen_frame_layout)).removeView(newV);
                                    onBackPressed();
                                }
                            });
                        }
                    }).start();
                }
            }
        });
    }

    public void setCountdown(final String currentTime) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ((TextView) countDownView.findViewById(R.id.time_remaining_field))
                        .setText(currentTime);
            }
        });
    }

    public void setCoinsCount(final int coinsCount) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ((TextView) coinsCountView.findViewById(R.id.coins_field))
                        .setText("" + coinsCount);
                GlobalInformation.lastGameCoins = coinsCount;
            }
        });
    }
}