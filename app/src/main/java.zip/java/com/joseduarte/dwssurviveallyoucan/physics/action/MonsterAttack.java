package com.joseduarte.dwssurviveallyoucan.physics.action;

import com.joseduarte.dwssurviveallyoucan.entities.Entity;
import com.joseduarte.dwssurviveallyoucan.entities.EntitySpawner;

public class MonsterAttack extends Attack {

    private int attackRange = 50;

    public MonsterAttack(Entity producerEntity, int toSide) {
        super(producerEntity, toSide);
    }

    public void attackTo(Entity entity) {
        entity.isBeingAttacked(true);

        if(inAttackRange(entity, attackRange)) {
            entity.addEffect(effect);
            entity.hurt();
        }
    }

    public void attackTo(Entity entity, int side) {
        entity.isBeingAttacked(true);

        attackingToSide = side;
        if(inAttackRange(entity, attackRange)) {
            entity.addEffect(effect);
            entity.hurt();

            if(!entity.isEntityAlive()) {
                entity.getGame().addCoins(EntitySpawner.COINS_PER_MONSTER);
            }
        }
    }
}
